﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**************************************
*                                     *
*   RuneScape Swapping Calculator     *
*      Created By @SwanTheCoder       *
*         March, 12th, 2016           *
*                                     *
***************************************/

namespace Swapping_Calculator
{
    public partial class Form1 : Form
    {

        //These are all doubles for our rates that the user will type into the text field.
        //We will use these rates to do arithmetic to figure out the "swapped" GP amount.
        private double osrs_To_Rs3_Rate = 0;
        private double rs3_To_Osrs_Rate = 0;
        private double osrs_To_DMM_Rate = 0;
        private double rs3_To_DMM_Rate = 0;

        //The amount of money that was taken to swap. 
        private double osrs_To_Rs3_Taken;
        private double rs3_To_Osrs_Taken;
        private double osrs_To_DMM_Taken;
        private double rs3_To_DMM_Taken;

        //The amount of money that will be given to the player.
        private double osrs_To_Rs3_Given;
        private double rs3_To_Osrs_Given;
        private double osrs_To_DMM_Given;
        private double rs3_To_DMM_Given;

        public Form1()
        {
            InitializeComponent();
        }

        //Initialization
        private void Form1_Load(object sender, EventArgs e)
        {

            //string welcomeMessage = "Thank You For Using Swan's Swapping Calculator. https://twitter.com/SwanTheCoder";
            //MessageBox.Show(welcomeMessage);

        }


        //Controls what happens when the user types in a Rate for 07 -> Rs3
        private void RateOSRSToRs3(object sender, EventArgs e)
        { 

            //Converting the string "rate" the user types in, into a double
            if (rate07ToRs3.Text != null) {

                //Parses to double and turns ReadOnly off on Taken
                Double.TryParse(rate07ToRs3.Text, out osrs_To_Rs3_Rate);
                taken07ToRs3.ReadOnly = false;

            }

        }

        //Controls what happens when the user types in a Rate for Rs3 -> 07
        private void RateRS3To07(object sender, EventArgs e)
        {

            //Converting the string "rate" the user types in, into a double
            if (rateRs3To07.Text != null)
            {

                //Parses to double and turns ReadOnly off on Taken
                Double.TryParse(rateRs3To07.Text, out rs3_To_Osrs_Rate);
                takenRs3To07.ReadOnly = false;

            }

        }

        //Controls what happens when the user types in a Rate for 07 -> DMM
        private void Rate07ToDMM(object sender, EventArgs e)
        {

            //Converting the string "rate" the user types in, into a double
            if (rate07ToDeadMan.Text != null)
            {

                //Parses to double and turns ReadOnly off on Taken
                Double.TryParse(rate07ToDeadMan.Text, out osrs_To_DMM_Rate);
                taken07ToDMM.ReadOnly = false;

            }

        }

        private void RateRs3ToDMM(object sender, EventArgs e)
        {

            //Converting the string "rate" the user types in, into a double
            if (rateRs3ToDeadMan.Text != null)
            {

                //Parses to double and turns ReadOnly off on Taken
                Double.TryParse(rateRs3ToDeadMan.Text, out rs3_To_DMM_Rate);
                takenRs3ToDMM.ReadOnly = false;

            }

        }

        //Actions that occur when user types in amount they've taken (07->RS3)
        private void OsrsToRs3Taken(object sender, EventArgs e)
        {

            //Converts to the amount of money taken to a double.
            if (taken07ToRs3.Text != null) {

                //Converts the Amount Taken to a Double so we can do arithmetic
                Double.TryParse(taken07ToRs3.Text, out osrs_To_Rs3_Taken);

                //Multiplying the amount of OSRS Taken by the Rate to get the RS3
                osrs_To_Rs3_Given = (osrs_To_Rs3_Taken * osrs_To_Rs3_Rate);

                //Place the RS3 GP inside of the Give Text Field.
                giveRs3.Text = osrs_To_Rs3_Given.ToString();

            }

        }

        //Actions that occur when user types in amount they've taken (RS3->07)
        private void Rs3ToOSRSTaken(object sender, EventArgs e)
        {

            //Converts to the amount of money taken to a double.
            if (takenRs3To07.Text != null)
            {

                //Converts the Amount Taken to a Double so we can do arithmetic
                Double.TryParse(takenRs3To07.Text, out rs3_To_Osrs_Taken);

                //Dividing the amount of RS3 Taken by the Rate to get OSRS
                rs3_To_Osrs_Given = (rs3_To_Osrs_Taken / rs3_To_Osrs_Rate);

                //Place the OSRS GP inside of the Give Text Field.
                giveOSRS.Text = rs3_To_Osrs_Given.ToString();

            }

        }

        private void OSRSToDMMTaken(object sender, EventArgs e)
        {

            //Converts to the amount of money taken to a double.
            if (taken07ToDMM.Text != null)
            {

                //Converts the Amount Taken to a Double so we can do arithmetic
                Double.TryParse(taken07ToDMM.Text, out osrs_To_DMM_Taken);

                //Multiplying the amount of OSRS Taken by the Rate to get the DMM
                osrs_To_DMM_Given = (osrs_To_DMM_Taken * osrs_To_DMM_Rate);

                //Place the DMM GP inside of the Give Text Field.
                giveDMM.Text = osrs_To_DMM_Given.ToString();

            }

        }

        private void RS3ToDMMTaken(object sender, EventArgs e)
        {

            if (takenRs3ToDMM.Text != null)
            {

                //Converts the Amount Taken to a Double so we can do arithmetic
                Double.TryParse(takenRs3ToDMM.Text, out rs3_To_DMM_Taken);

                //Multiplying the amount of RS# Taken by the Rate to get DMM
                rs3_To_DMM_Given = (rs3_To_DMM_Taken * rs3_To_DMM_Rate);

                //Place the DMM GP inside of the Give Text Field.
                giveDMM_Rs3.Text = rs3_To_DMM_Given.ToString();

            }

        }

        //This will open up the link to @SwanTheCoder's Website/Thread when clicked (For Label At Bottom)
        private void OpenURL(object sender, LinkLabelLinkClickedEventArgs e)
        {

            System.Diagnostics.Process.Start("https://twitter.com/SwanTheCoder");

        }

        //This function resets every single text field back to zero and turns ReadOnly back on.
        private void TakenGiveClick(object sender, EventArgs e)
        {
           
            //07 -> RS3
            taken07ToRs3.Text = "0";
            taken07ToRs3.ReadOnly = true;

            //RS3 -> 07
            takenRs3To07.Text = "0";
            takenRs3To07.ReadOnly = true;

            //07 -> DMM
            taken07ToDMM.Text = "0";
            taken07ToDMM.ReadOnly = true;

            //RS3 -> DMM
            takenRs3ToDMM.Text = "0";
            takenRs3ToDMM.ReadOnly = true;

        }
        
        //This will clear every single rate.
        private void RatesClear(object sender, EventArgs e)
        {

            //Setting all Rates back to Zero
            rate07ToRs3.Text = "0";
            rateRs3To07.Text = "0";
            rate07ToDeadMan.Text = "0";
            rateRs3ToDeadMan.Text = "0";

            //Making the other Text Fields read only again
            taken07ToRs3.ReadOnly = true;
            takenRs3To07.ReadOnly = true;
            taken07ToDMM.ReadOnly = true;
            takenRs3ToDMM.ReadOnly = true;
        
        }

        //Exits Program (Clicking File -> Exit)
        private void QuitProgram(object sender, EventArgs e)
        {

            Application.Exit();

        }

        //Opens up Github
        private void SupportAndSourceCodeLinks(object sender, EventArgs e)
        {

            System.Diagnostics.Process.Start("https://twitter.com/SwanTheCoder");

        }
    }
}
