﻿namespace Swapping_Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.rate07ToRs3 = new System.Windows.Forms.TextBox();
            this.rateRs3To07 = new System.Windows.Forms.TextBox();
            this.rate07ToDeadMan = new System.Windows.Forms.TextBox();
            this.rateRs3ToDeadMan = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.label6 = new System.Windows.Forms.Label();
            this.taken07ToRs3 = new System.Windows.Forms.TextBox();
            this.takenRs3To07 = new System.Windows.Forms.TextBox();
            this.taken07ToDMM = new System.Windows.Forms.TextBox();
            this.takenRs3ToDMM = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.giveRs3 = new System.Windows.Forms.TextBox();
            this.giveOSRS = new System.Windows.Forms.TextBox();
            this.giveDMM = new System.Windows.Forms.TextBox();
            this.giveDMM_Rs3 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.donateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openSourceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // rate07ToRs3
            // 
            this.rate07ToRs3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.rate07ToRs3.Location = new System.Drawing.Point(7, 79);
            this.rate07ToRs3.Name = "rate07ToRs3";
            this.rate07ToRs3.Size = new System.Drawing.Size(100, 20);
            this.rate07ToRs3.TabIndex = 0;
            this.rate07ToRs3.Text = "0";
            this.rate07ToRs3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.rate07ToRs3.TextChanged += new System.EventHandler(this.RateOSRSToRs3);
            // 
            // rateRs3To07
            // 
            this.rateRs3To07.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.rateRs3To07.Location = new System.Drawing.Point(7, 122);
            this.rateRs3To07.Name = "rateRs3To07";
            this.rateRs3To07.Size = new System.Drawing.Size(100, 20);
            this.rateRs3To07.TabIndex = 0;
            this.rateRs3To07.Text = "0";
            this.rateRs3To07.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.rateRs3To07.TextChanged += new System.EventHandler(this.RateRS3To07);
            // 
            // rate07ToDeadMan
            // 
            this.rate07ToDeadMan.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.rate07ToDeadMan.Location = new System.Drawing.Point(7, 161);
            this.rate07ToDeadMan.Name = "rate07ToDeadMan";
            this.rate07ToDeadMan.Size = new System.Drawing.Size(100, 20);
            this.rate07ToDeadMan.TabIndex = 0;
            this.rate07ToDeadMan.Text = "0";
            this.rate07ToDeadMan.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.rate07ToDeadMan.TextChanged += new System.EventHandler(this.Rate07ToDMM);
            // 
            // rateRs3ToDeadMan
            // 
            this.rateRs3ToDeadMan.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.rateRs3ToDeadMan.Location = new System.Drawing.Point(7, 200);
            this.rateRs3ToDeadMan.Name = "rateRs3ToDeadMan";
            this.rateRs3ToDeadMan.Size = new System.Drawing.Size(100, 20);
            this.rateRs3ToDeadMan.TabIndex = 0;
            this.rateRs3ToDeadMan.Text = "0";
            this.rateRs3ToDeadMan.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.rateRs3ToDeadMan.TextChanged += new System.EventHandler(this.RateRs3ToDMM);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.label1.Location = new System.Drawing.Point(4, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "OSRS -> RS3";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.label2.Location = new System.Drawing.Point(4, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "RS3 -> OSRS";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.label3.Location = new System.Drawing.Point(4, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "OSRS -> DMM";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.label4.Location = new System.Drawing.Point(8, 184);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "RS3 -> DMM";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.Location = new System.Drawing.Point(3, 36);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 20);
            this.label5.TabIndex = 3;
            this.label5.Text = "Rates (???:1)";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label6.Location = new System.Drawing.Point(121, 36);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 20);
            this.label6.TabIndex = 3;
            this.label6.Text = "Taken (in M)";
            // 
            // taken07ToRs3
            // 
            this.taken07ToRs3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.taken07ToRs3.Location = new System.Drawing.Point(125, 79);
            this.taken07ToRs3.Name = "taken07ToRs3";
            this.taken07ToRs3.ReadOnly = true;
            this.taken07ToRs3.Size = new System.Drawing.Size(100, 20);
            this.taken07ToRs3.TabIndex = 0;
            this.taken07ToRs3.Text = "0";
            this.taken07ToRs3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.taken07ToRs3.TextChanged += new System.EventHandler(this.OsrsToRs3Taken);
            // 
            // takenRs3To07
            // 
            this.takenRs3To07.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.takenRs3To07.Location = new System.Drawing.Point(125, 122);
            this.takenRs3To07.Name = "takenRs3To07";
            this.takenRs3To07.ReadOnly = true;
            this.takenRs3To07.Size = new System.Drawing.Size(100, 20);
            this.takenRs3To07.TabIndex = 0;
            this.takenRs3To07.Text = "0";
            this.takenRs3To07.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.takenRs3To07.TextChanged += new System.EventHandler(this.Rs3ToOSRSTaken);
            // 
            // taken07ToDMM
            // 
            this.taken07ToDMM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.taken07ToDMM.Location = new System.Drawing.Point(125, 161);
            this.taken07ToDMM.Name = "taken07ToDMM";
            this.taken07ToDMM.ReadOnly = true;
            this.taken07ToDMM.Size = new System.Drawing.Size(100, 20);
            this.taken07ToDMM.TabIndex = 0;
            this.taken07ToDMM.Text = "0";
            this.taken07ToDMM.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.taken07ToDMM.TextChanged += new System.EventHandler(this.OSRSToDMMTaken);
            // 
            // takenRs3ToDMM
            // 
            this.takenRs3ToDMM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.takenRs3ToDMM.Location = new System.Drawing.Point(125, 200);
            this.takenRs3ToDMM.Name = "takenRs3ToDMM";
            this.takenRs3ToDMM.ReadOnly = true;
            this.takenRs3ToDMM.Size = new System.Drawing.Size(100, 20);
            this.takenRs3ToDMM.TabIndex = 0;
            this.takenRs3ToDMM.Text = "0";
            this.takenRs3ToDMM.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.takenRs3ToDMM.TextChanged += new System.EventHandler(this.RS3ToDMMTaken);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label7.Location = new System.Drawing.Point(249, 36);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 20);
            this.label7.TabIndex = 3;
            this.label7.Text = "Give (in M)";
            // 
            // giveRs3
            // 
            this.giveRs3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.giveRs3.Location = new System.Drawing.Point(253, 79);
            this.giveRs3.Name = "giveRs3";
            this.giveRs3.ReadOnly = true;
            this.giveRs3.Size = new System.Drawing.Size(100, 20);
            this.giveRs3.TabIndex = 0;
            this.giveRs3.Text = "0";
            this.giveRs3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // giveOSRS
            // 
            this.giveOSRS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.giveOSRS.Location = new System.Drawing.Point(253, 122);
            this.giveOSRS.Name = "giveOSRS";
            this.giveOSRS.ReadOnly = true;
            this.giveOSRS.Size = new System.Drawing.Size(100, 20);
            this.giveOSRS.TabIndex = 0;
            this.giveOSRS.Text = "0";
            this.giveOSRS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // giveDMM
            // 
            this.giveDMM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.giveDMM.Location = new System.Drawing.Point(253, 161);
            this.giveDMM.Name = "giveDMM";
            this.giveDMM.ReadOnly = true;
            this.giveDMM.Size = new System.Drawing.Size(100, 20);
            this.giveDMM.TabIndex = 0;
            this.giveDMM.Text = "0";
            this.giveDMM.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // giveDMM_Rs3
            // 
            this.giveDMM_Rs3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.giveDMM_Rs3.Location = new System.Drawing.Point(248, 200);
            this.giveDMM_Rs3.Name = "giveDMM_Rs3";
            this.giveDMM_Rs3.ReadOnly = true;
            this.giveDMM_Rs3.Size = new System.Drawing.Size(100, 20);
            this.giveDMM_Rs3.TabIndex = 0;
            this.giveDMM_Rs3.Text = "0";
            this.giveDMM_Rs3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.button1.Location = new System.Drawing.Point(125, 226);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(228, 31);
            this.button1.TabIndex = 4;
            this.button1.Text = "Clear";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.TakenGiveClick);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.button2.Location = new System.Drawing.Point(7, 226);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 31);
            this.button2.TabIndex = 4;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.RatesClear);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(360, 24);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // quitToolStripMenuItem
            // 
            this.quitToolStripMenuItem.Name = "quitToolStripMenuItem";
            this.quitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.quitToolStripMenuItem.Text = "Quit";
            this.quitToolStripMenuItem.Click += new System.EventHandler(this.QuitProgram);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.donateToolStripMenuItem,
            this.openSourceToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // donateToolStripMenuItem
            // 
            this.donateToolStripMenuItem.Name = "donateToolStripMenuItem";
            this.donateToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.donateToolStripMenuItem.Text = "Support";
            this.donateToolStripMenuItem.Click += new System.EventHandler(this.SupportAndSourceCodeLinks);
            // 
            // openSourceToolStripMenuItem
            // 
            this.openSourceToolStripMenuItem.Name = "openSourceToolStripMenuItem";
            this.openSourceToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.openSourceToolStripMenuItem.Text = "Source Code";
            this.openSourceToolStripMenuItem.Click += new System.EventHandler(this.SupportAndSourceCodeLinks);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(49, 268);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(267, 13);
            this.linkLabel1.TabIndex = 7;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "RuneScape Swapping Calculator By @SwanTheCoder";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.OpenURL);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(360, 292);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rateRs3ToDeadMan);
            this.Controls.Add(this.rate07ToDeadMan);
            this.Controls.Add(this.rateRs3To07);
            this.Controls.Add(this.giveDMM_Rs3);
            this.Controls.Add(this.takenRs3ToDMM);
            this.Controls.Add(this.giveDMM);
            this.Controls.Add(this.taken07ToDMM);
            this.Controls.Add(this.giveOSRS);
            this.Controls.Add(this.giveRs3);
            this.Controls.Add(this.takenRs3To07);
            this.Controls.Add(this.taken07ToRs3);
            this.Controls.Add(this.rate07ToRs3);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Swan\'s Swapping Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox rate07ToRs3;
        private System.Windows.Forms.TextBox rateRs3To07;
        private System.Windows.Forms.TextBox rate07ToDeadMan;
        private System.Windows.Forms.TextBox rateRs3ToDeadMan;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox giveDMM_Rs3;
        private System.Windows.Forms.TextBox takenRs3ToDMM;
        private System.Windows.Forms.TextBox giveDMM;
        private System.Windows.Forms.TextBox taken07ToDMM;
        private System.Windows.Forms.TextBox giveOSRS;
        private System.Windows.Forms.TextBox giveRs3;
        private System.Windows.Forms.TextBox takenRs3To07;
        private System.Windows.Forms.TextBox taken07ToRs3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem donateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openSourceToolStripMenuItem;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}

